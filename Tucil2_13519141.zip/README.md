# IF2211-Stima-Tucil2
Menentukan Pengambilan Mata Kuliah Menggunakan Topological Sort

Menggunakan Algoritma Decrease and Conquer 
Implementasi sederhananya adalah mengurangi list mata kuliah yang belum diambil satu-persatu
Dengan cara mengeluarkan mata kuliah yang sudah tidak memiliki prasyarat
Hingga seluruh mata kuliah telah dikeluarkan (sudah diambil)

Requirement:
Python IDLE (3.6++)
*Author used 3.8

Cara Menggunakan Program:
1. Klik kanan pada source code yang berada di folder src
2. Pilih edit with IDLE
3. Setelah terbuka source code di text editor IDLE, pilih run module atau pencet F5
4. Input file yang ingin dibaca dengan format sesuai contoh pesan keluaran
5. Akan ditampilkan mata kuliah yang diambil tiap semesternya hingga mata kuliah habis
6. Jika ingin run kembali, pencet F5 saja di text editor IDLE

Untuk penambahan test-case, pastikan setelah tanda ',' menggunakan spasi (sesuai test-case yang sudah ada)
Karena kalkulasi yang author lakukan akan error jika tidak ada spasi

Author: Naufal Yahya Kurnianto 13519141 K-03 IF2211 Strategi Algoritma
Terima kasih kepada teman-teman yang telah membantu :D
